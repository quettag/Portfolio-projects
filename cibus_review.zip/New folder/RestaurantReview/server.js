var express = require("express");

var restaurantController = require('./controllers/restaurantController');
var commentController = require('./controllers/commentController');
var userController = require('./controllers/userController');

var app = express();

app.use(express.static("./public"));
app.use(express.json());


app.route('/restaurants').get(restaurantController.getAllRestaurants);
app.route('/restaurants').post(restaurantController.searchRestaurants);

app.route('/comments').get(commentController.getAllComments);
app.route('/comments').post(commentController.addComment);
app.route('/comments/:id').put(commentController.updateComment);
app.route('/comments/:id').delete(commentController.deleteComment);

app.route('/user').get(userController.getAllUsers);
app.route('/login').post(userController.getLoginCredentials);
app.route('/user').post(userController.addUser);

//app.route('/user/:id').put(userController.updateUser);
//app.route('/user/:id').delete(userController.deleteUser);

const cors=require("cors");
const corsOptions ={
   origin:'*', 
   credentials:true,            //access-control-allow-credentials:true
   optionSuccessStatus:200,
}

app.use(cors(corsOptions)) // Use this after the variable declaration

app.listen(8080, "127.0.0.1");
console.log("web server running @ http://127.0.0.1:8080");