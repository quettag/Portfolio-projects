var restaurant_url = "/restaurants";
var restaurant_array = []; // This creates an empty movie array
var restaurantCount = 0;
/*  There are two categories: "Now Showing" and "Coming Soon". This variable states which 
    category of movies should be listed when the home page is first loaded. */
var category = "Home";
var currentIndex=0;//it will keep tracking the current movie we are clicking
var comment_url = "/comments";
var comment_array = []; // This creates an empty comment array
var starBWImage = 'images/star_bw.png';
var starImage = 'images/star.png';
var stars = 0;