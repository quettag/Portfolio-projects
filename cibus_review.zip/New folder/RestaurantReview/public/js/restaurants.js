//This function is to call the movies api and get all the movies
//that is showing in Shaw Theatres for Showing Now and Coming Soon
//W8.1 Slide 23
function getRestaurantData() {
    var request = new XMLHttpRequest();
    request.open('GET', restaurant_url, true);
    //This function will be called when data returns from the web api    
    request.onload = function () {
        //get all the movies records into our movie array        
        restaurant_array = JSON.parse(request.responseText);
        //Fetch the comments as well        
        fetchComments();
        console.log(restaurant_array) // output to console        
        //call the function so as to display all movies tiles for "Now Showing"        	
        displayRestaurant(category);
    };

    //This command starts the calling of the movies web api    
    request.send();
}
//W8.1 Slide 25

function displayRestaurant(category) {
    var table = document.getElementById("restaurantsTable");
    var restaurantCount = 0;
    var message = "";

    table.innerHTML = "";
    totalRestaurants = restaurant_array.length;
    for (var count = 0; count < totalRestaurants; count++) {
            var pictures = restaurant_array[count].pictures;
            var restaurant_name = restaurant_array[count].restaurant_name;
            var cell = '<div class="card col-md-3" ><img class="card-img-top" src="' + pictures + '" alt="Card image cap">\
                        <div class="card-body"><i class="far fa-comment fa-lg" style="float:left;cursor:pointer" data-toggle="modal" data-target="#commentModal" item="' + count + '" onClick="showRestaurantComments(this)"></i>\
                        <h5 style="padding-left:30px;cursor:pointer" data-toggle="modal" data-target="#restaurantModal" class="card-title" item="' + count + '" onClick="showRestaurantDetails(this)">'+restaurant_name+'</h5></div>\
</div>'
            table.insertAdjacentHTML('beforeend', cell);
            restaurantCount++;
        }
    message = restaurantCount + " Restaurants ";
    document.getElementById("summary").textContent = message;
    document.getElementById("parent").textContent = "";

    }
    //W8.1 Slide 25
   


//W8.1 Slide 29

//This function is to display the "Now Showing" movies
function listRestaurants() {
    category = "home";
    displayRestaurant(category);
    document.getElementById("homeMenu").classList.add("active");
    document.getElementById("comingMenu").classList.remove("active");
    document.getElementById("aboutMenu").classList.remove("active");
}

//This function is to display the "Coming Soon" movies

//This function is to display the individual movies details
//whenever the user clicks on "See More"
function showRestaurantDetails(element){
    var item = element.getAttribute("item");
    currentIndex = item;
    console.log("CurrentIndex clicked is ", currentIndex);
    document.getElementById("restaurantName").textContent = restaurant_array[item].restaurant_name;
    document.getElementById("address").textContent = restaurant_array[item].address;
    document.getElementById("restaurantLogo").src = restaurant_array[item].pictures;
    //document.getElementById("link").textContent = restaurant_array[item].restaurant_link;
    //document.getElementById("halal").textContent = restaurant_array[item].halal;
    //document.getElementById("vegetarian").textContent = restaurant_array[item].vegetarian;
    document.getElementById("cuisine").textContent = restaurant_array[item].cuisine
    document.getElementById("timings").textContent = restaurant_array[item].timings;
    document.getElementById("number").textContent = restaurant_array[item].contact_num;
    document.getElementById("date").textContent = restaurant_array[item].latest_date_posted;
    
}
function searchRestaurants() {
    var searching = new Object();
    searching.restaurant_name = document.getElementById("search").value;
    console.log(searching)
    var postSearching = new XMLHttpRequest();
    postSearching.open("POST", "http://127.0.0.1:8080/restaurants", true);
    postSearching.setRequestHeader("Content-Type", "application/json");
    postSearching.onload = function(){
        restaurant_array = JSON.parse(postSearching.responseText);
        displayRestaurant();
    };
    postSearching.send(JSON.stringify(searching));
}


//This function opens a new window/tab and loads the
//particular movie in the cinema website
/*
function buyTicket() {
    window.open(restaurant_array[currentIndex].buy, "_blank");
}
*/