function registerMe(){
    var registerUser= new XMLHttpRequest();
   //endpoint 
    registerUser.open('POST', "http://127.0.0.1:8080/user", true);
    //json format
    registerUser.setRequestHeader("Content-Type", "application/json");
    //This command starts the calling of the register user api
    registerUser.onload = function () {
        console.log("new user sent");
        $('#registerModal').modal('hide');
        $('#successModal').modal('show');
        //$('#loginModal').modal('show');
        //$('#logoutModal').modal('show');
    }
    var name = document.getElementById("Name").value;
    var email = document.getElementById("Email").value;
    var username = document.getElementById("Username").value;
    var pwd = document.getElementById("Password").value;
    console.log(username,name,email,pwd);
    
    var payload ={name:name,email:email,username:username,password:pwd};
    console.log(payload);
    registerUser.send(JSON.stringify(payload));
}