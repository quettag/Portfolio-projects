//"use strict";
const UserDB = require('../models/UserDB');
const User = require('../models/User');

const bcrypt1 = require('bcrypt');

var jwt = require('jsonwebtoken');
var secret = "somesecretkey";

var userDB = new UserDB();
function getAllUsers(request, respond) {
    userDB.getAllUsers(function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });
}

function addUser(request, respond) {
    //var now = new Date();
    var password = bcrypt1.hashSync(request.body.password, 10);
    // console.log(password);
    var user = new User(null,request.body.name, request.body.email, request.body.username, password);
    userDB.addUser(user, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });
}
function getLoginCredentials(request, respond) {
    //var userid = request.params.userid;
    var username = request.body.username;
    var pwd = request.body.password;
    var msg = "";
    //console.log('in user controller', userid, pwd);
    userDB.getLoginCredentials(username, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            if (result.length > 0) {
                const hash = result[0].password;
                //console.log(hash);
                var flag = bcrypt1.compareSync(pwd, hash);
                //value of flag is true or false
                //console.log(flag);
                //if(pwd == result[0].password){
                if (flag) {
                    //jwt--jsonwebtoken
                    var token = jwt.sign(username, secret);
                    respond.json({result:token});
                    // msg = "SUCCESS!";
                    // console.log(msg);
                }
                else {
                    // msg = "FAIL!";
                    // console.log(msg);
                    // respond.json({ result:"invalid password"});
                    respond.json({ result: flag});
                }
            }
            else {
                 respond.json({ result:"user not found"});
            }
        }
    });
}

function prepareMessage(msg) {
    var obj = { "message": msg };
    console.log(obj);
    return obj;
}



module.exports = { getAllUsers, addUser, getLoginCredentials, prepareMessage,};