"use strict";
const RestaurantsDB = require('../models/RestaurantsDB');
const Restaurant = require('../models/Restaurant');
const e = require('express');
const { json } = require('express');

var restaurantsDB = new RestaurantsDB();

function getAllRestaurants(request, respond){
    restaurantsDB.getAllRestaurants(function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}
function searchRestaurants(request, respond) {
    var search = request.body.restaurant_name
    restaurantsDB.searchRestaurants(search, function (error, result) {
        if (error) {
            respond.json(error);
        } else (
            respond.json(result)
        )
    });
}; 



module.exports = {getAllRestaurants,searchRestaurants};