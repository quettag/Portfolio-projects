"use strict";
var db = require('../db-connections');
class userDB{
    
    getLoginCredentials(username, callback){
       var sql = "SELECT password FROM restaurant_review.user WHERE username = ?";
       db.query(sql, [username], callback);
    }

    getAllUsers(callback){
        var sql = "SELECT * FROM restaurant_review.user";
        db.query(sql, callback);
    }
    addUser(user,callback){
        var sql = "INSERT INTO user(name,email,username,password) VALUES(?,?,?,?)";
        db.query(sql,[user.getName(),user.getEmail(),user.getUsername(),user.getPassword()],callback);

    }
    /*
    updateUser(user, callback){
        var sql = "UPDATE user SET name = ?, password = ?, email = ?, username = ?  WHERE _id = ?";
        return db.query(sql,[user.getName(), user.getPassword(),user.getEmail(),user.getUsername(),user.getId()], callback);
    }
    deleteUser(userID, callback){
        var sql = "DELETE from user WHERE _id = ?";
        return db.query(sql,[userID],callback);
    }
    */
}

module.exports = userDB;