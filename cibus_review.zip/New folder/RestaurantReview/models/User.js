"use strict"

class users{
    constructor(id, name, email, username, password){
        this.id = id;
        this.name = name;
        this.email = email;
        this.username = username;
        this.password = password
    }
    getId(){
        return this.id;
    }
    getName(){
        return this.name;
    }
    getEmail(){
        return this.email;
    }
    getUsername(){
        return this.username    
    }
    getPassword(){
        return this.password;
    }



    setName(name){
        this.name = name;
    }
    setEmail(email){
        this.email = email;
    }
    setUsername(username){
        this.username = username;
    }
    setPassword(password){
        this.password = password;
    }


}
    module.exports = users;