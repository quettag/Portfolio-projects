"use strict";

class Comment {
constructor(id, review, stars,username,restaurant_id,datePosted) 
{
this.id = id;
this.review = review;
this.stars = stars;
this.username = username;
this.restaurant_id = restaurant_id;
this.datePosted = datePosted;
}
//add the set and get methods here
getId() {
return this.id;
}
getReview() {
return this.review;
}
getStars() {
return this.stars;
}
getUsername(){
return this.username;
}
getRestaurant_id(){
return this.restaurant_id;
}
getDatePosted() {
return this.datePosted;
}




setReview(review) {
this.review = review;
}
setStars(stars) {
this.stars = stars;
}
setUsername(username){
this.username = username;
}
setRestaurant_id(restaurant_id){
this.restaurant_id = restaurant_id;
}
setDatePosted(datePosted) {
this.datePosted = datePosted;
}
}
module.exports = Comment;

