"use strict";

class Restaurant {
    constructor(id, restaurant_name, address,restaurant_link, pictures, cuisine, timings, contact_num, latest_date_posted) 
    {
    this.id = id;
    this.restaurant_name = restaurant_name
    this.address = address
    this.restaurant_link
    this.pictures = pictures
    this.cuisine = cuisine
    this.timings = timings
    this.contact_num = contact_num
    this.latest_date_posted = latest_date_posted
    }
    getId(){
        return this.id;
    }
    getRestaurant_name(){
        return this.restaurant_name;
    }
    getAddress(){
        return this.address;
    }
    getRestaurant_link(){
        return this.restaurant_link
    }
    getPictures(){
        return this.pictures
    }
    getCuisine(){
        return this.cuisine
    }
    getTimings(){
        return this.timings
    }
    getContact_num(){
        return this.contact_num
    }
    getLatest_date_posted(){
        return this.latest_date_posted
    }


    setRestaurant_name(restaurant_name){
        this.restaurant_name = restaurant_name
    }
    setAddress(address){
        this.address = address
    }
    setRestaurant_link(restaurant_link){
        this.restaurant_link = restaurant_link
    }
    setPictures(pictures){
        this.pictures = pictures

    }
    setCuisine(cuisine){
        this.cuisine = cuisine
    }
    setTimings(timings){
        this.timings = timings
    }
    setContact_num(contact_num){
        this.contact_num = contact_num
    }
    setLatest_date_posted(latest_date_posted){
        this.latest_date_posted = latest_date_posted
    }
}
module.exports = Restaurant;