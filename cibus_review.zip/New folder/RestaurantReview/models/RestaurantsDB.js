"use strict";

var db = require('../db-connections');
class RestaurantsDB{
    getAllRestaurants(callback){
        var sql = "SELECT * from restaurant_review.restaurant";
        db.query(sql, callback)
    }
    searchRestaurants(search, callback) {
        var sql = "SELECT * FROM restaurant WHERE restaurant_name LIKE ?";
        db.query(sql, ['%' + search + '%'], callback)
    }

}

module.exports = RestaurantsDB;