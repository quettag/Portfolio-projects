"use strict";

var db = require('../db-connections');
class CommentsDB{
    getAllComments(callback){
        var sql = "SELECT * from restaurant_review.comment";
        db.query(sql, callback)
    }
    addComment(comment,callback){
        var sql = "INSERT INTO comment(review,stars,username,restaurant_id,datePosted) VALUES(?,?,?,?,?)";
        db.query(sql,[comment.getReview(),comment.getStars(),comment.getUsername(),comment.getRestaurant_id(),comment.getDatePosted()],callback);

    }
    updateComment(comment, callback){
        var sql = "UPDATE comment SET review = ?, stars = ?, datePosted = ?  WHERE _id = ?";
        return db.query(sql,[comment.getReview(), comment.getStars(),comment.getDatePosted(),comment.getId()], callback);
    }
    deleteComment(commentID, callback){
        var sql = "DELETE from comment WHERE _id = ?";
        return db.query(sql,[commentID],callback);
    }

}

module.exports = CommentsDB;