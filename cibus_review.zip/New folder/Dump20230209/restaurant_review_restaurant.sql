-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: restaurant_review
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restaurant_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pictures` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cuisine` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timings` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_num` int NOT NULL,
  `latest_date_posted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`_id`),
  UNIQUE KEY `_id_UNIQUE` (`_id`),
  UNIQUE KEY `restaurant_name_UNIQUE` (`restaurant_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES (1,'Nandos','4 Tampines Central 5, #01-46 Tampines Mall, Singapore 529510','https://www.nandos.com.sg/','/images/Nandos-Logo.png','South African','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234567,'2022-10-02 00:00:00'),(2,'Din Tai Fung','4 Tampines Central 5, #02-01 Tampines Mall, Singapore 529510','https://dintaifung.com.sg/','/images/dinTaiFung.jpg','Chinese','Monday to Fridays 10am - 10pm Weekends 9:30am-11:30pm',61234568,'2022-04-20 00:00:00'),(3,'Popeyes','10 Tampines Central 1, #03-16B Tampines One, Singapore 529536','https://www.popeyes.com.sg/','/images/popeyes.png','North American','Monday to Fridays 11am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(4,'Texas Chicken','Address: 2 Tampines Central 5, #05-03 Century Square, Singapore 529509','https://sg.texaschicken.com/','/images/Texas_chicken.jpg','North American','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234570,'2022-07-17 00:00:00'),(5,'Saffrons','201D Tampines St. 21, #01-1163, Singapore 524201','https://saffrons.com.sg/','/images/saffrons.png','Indian','Monday to Fridays 1pm - 11pm Weekends 10am-11pm',61234567,'2023-01-01 00:00:00'),(6,'McDonalds','4 Tampines Central 5, #01 - 33 Tampines Mall, Singapore 529510','https://mcdonalds.com.sg/','/images/maccas.png','western','Open 24 / 7',62345678,'Sun Jan 15 2023 23:36:11 GMT+0800 (Singapore Standard Time)'),(8,'Nuodle','1 Tampines Walk, #01-101, Singapore 528523','www.nuodle.asia','/images/nuodle.png','Chinese','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(9,'Saap Saap Thai','#01-100, Our Tampines Hub, 51 Tampines Ave 4, 529684','https://www.saapsaapthai.sg/','/images/saapsaap.jpg','Thai','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(10,'KFC','4 Tampines Central 5, #01-47 Tampines Mall, Singapore 529510','https://www.kfc.com.sg/','/images/Kfc_logo.png','Western','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(11,'Jinjja','78 Airport Blvd., #B1 - 247, Singapore 819666','https://www.jinjjachicken.com/','/images/jinjjachicken.png','Korean','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(12,'18 Cheff','1 Tampines Walk, #02-90/91, Singapore 528523','https://www.eighteenchefs.com/','/images/18_cheff.png','Mix','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00'),(13,'Sanook','10 Tampines Central 1, #03-25, Singapore 529536','http://www.sanookthaicuisine.com/menu','/images/sanook.png','Thai','Monday to Fridays 10am - 10pm Weekends 9am-11pm',61234569,'2022-05-16 00:00:00');
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-09 22:06:36
