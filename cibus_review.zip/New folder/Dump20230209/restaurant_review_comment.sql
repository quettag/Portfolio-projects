-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: restaurant_review
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `review` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `stars` int DEFAULT NULL,
  `username` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restaurant_id` int DEFAULT NULL,
  `datePosted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`_id`),
  UNIQUE KEY `_id_UNIQUE` (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (2,'Tried DTF the food is too overated',3,NULL,2,'Wed Dec 02 2020 12:33:09 GMT+0800 (Singapore Standard Time)'),(3,'Popeyes sucks, their biscuit is super dry and hard',1,NULL,3,'Wed Dec 02 2020 12:33:09 GMT+0800 (Singapore Standard Time)'),(4,'sdfghn',4,NULL,4,'Sun Jan 15 2023 02:43:42 GMT+0800 (Singapore Standard Time)'),(7,'not too ba',3,NULL,5,'Sun Jan 15 2023 15:34:16 GMT+0800 (Singapore Standard Time)'),(8,'it was dope',5,NULL,5,'Sun Jan 15 2023 02:57:44 GMT+0800 (Singapore Standard Time)'),(9,'it was dope',5,NULL,5,'Sun Jan 15 2023 02:57:44 GMT+0800 (Singapore Standard Time)'),(13,'not too ba',3,NULL,NULL,'Sun Jan 15 2023 15:59:09 GMT+0800 (Singapore Standard Time)'),(14,'last test before moving to resaurant',5,NULL,3,'Sun Jan 15 2023 16:02:36 GMT+0800 (Singapore Standard Time)'),(22,'testing 1',3,NULL,NULL,NULL),(23,'testings',3,NULL,NULL,NULL),(25,'testings',3,NULL,3,'Thu Jan 19 2023 09:52:09 GMT+0800 (Singapore Standard Time)'),(26,'testing 111',3,NULL,3,'Sun Jan 15 2023 23:38:21 GMT+0800 (Singapore Standard Time)'),(36,NULL,0,NULL,NULL,NULL),(38,'testing 29 jan second attemp',5,'pls work',5,''),(39,'testing 29 jan second attemp',5,'pls work',5,''),(42,'testinsss',5,'username',3,'2023-01-29 01:04:33'),(43,NULL,0,NULL,NULL,NULL),(44,'pls work',0,'pls work',NULL,'Sun Jan 29 2023 01:43:46 GMT+0800 (Singapore Standard Time)'),(45,'testing',0,'john',NULL,'Sun Jan 29 2023 01:48:37 GMT+0800 (Singapore Standard Time)'),(46,'gfcx',0,'babol',NULL,'Sun Jan 29 2023 01:51:23 GMT+0800 (Singapore Standard Time)'),(47,'fish',0,'bobby',NULL,'Sun Jan 29 2023 01:54:28 GMT+0800 (Singapore Standard Time)'),(48,'hopefully this works',0,'johnny',NULL,'Sun Jan 29 2023 01:55:27 GMT+0800 (Singapore Standard Time)'),(49,'ddd',0,'pls work again',NULL,'Sun Jan 29 2023 01:56:37 GMT+0800 (Singapore Standard Time)'),(50,'fdsz',0,'babol',NULL,'Sun Jan 29 2023 02:03:28 GMT+0800 (Singapore Standard Time)'),(54,'21',4,'1',5,'Sun Jan 29 2023 02:17:07 GMT+0800 (Singapore Standard Time)'),(57,'vbnm,.',4,'fghjkl',1,'Thu Feb 02 2023 13:53:10 GMT+0800 (Singapore Standard Time)'),(59,'nn',2,'nn',1,'Sun Feb 05 2023 05:13:56 GMT+0800 (Singapore Standard Time)'),(60,'s',1,'s',1,'Sun Feb 05 2023 07:36:09 GMT+0800 (Singapore Standard Time)'),(61,'lll',4,'Keanureeves',1,'Thu Feb 09 2023 14:41:04 GMT+0800 (Singapore Standard Time)');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-09 22:06:36
