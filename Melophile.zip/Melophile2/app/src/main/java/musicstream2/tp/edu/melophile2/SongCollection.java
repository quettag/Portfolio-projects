package musicstream2.tp.edu.melophile2;

public class SongCollection {
    private static Song[] songs = new Song[24];
    public SongCollection(){
        Song ImFine = new   Song("add_1","I'm Fine","Hentaidesu","https://p.scdn.co/mp3-preview/c3f6ad0fb7830d1688310713241d50e4dbed2d3d?cid=2afe87a64b0042dabf51f37318616965",1.11,R.drawable.imfine);
        Song JuneGloom = new Song("add_2","June Gloom","Prima","https://p.scdn.co/mp3-preview/21d0f94706f2c11f78c0a6dbe21c04a5cefa32ef?cid=2afe87a64b0042dabf51f37318616965",2.4,R.drawable.junegloom);
        Song Moow = new Song("add_3","Gymnopaedie","Moow","https://p.scdn.co/mp3-preview/a19b8640a37b3090fb5e50ed6d9e93e9823aabdb?cid=2afe87a64b0042dabf51f37318616965",2.58,R.drawable.moow);
        Song Wys = new Song("add_4","Comforting You","WYS","https://p.scdn.co/mp3-preview/3567f99d258c0e688bbdb6fe926dd8c393b98bc2?cid=2afe87a64b0042dabf51f37318616965",3.25,R.drawable.wys);

        Song Always = new Song("add_indie_1","Always it's always","Julien Lavoie","https://p.scdn.co/mp3-preview/3921313c721bc7c5220af437081ec595ed0fddb9?cid=2afe87a64b0042dabf51f37318616965",4.17,R.drawable.alwayssquare);
        Song Hybs = new Song("add_indie_2","Dancing with my Phone","HYBS","https://p.scdn.co/mp3-preview/2e0fcd47e646cc7124feae8da07e6e4d9e83aad6?cid=2afe87a64b0042dabf51f37318616965",3.39,R.drawable.hybs);
        Song Soap = new Song("add_indie_3","Call me","Soap","https://p.scdn.co/mp3-preview/f50b02cec6f6fa43037bee5788210f23b16c9cca?cid=2afe87a64b0042dabf51f37318616965",3.75,R.drawable.soap);
        Song Clairo = new Song("add_indie_4","Bubble gum","Clairo","https://p.scdn.co/mp3-preview/a3862a7c7030238f68fa40d0fe6e0df668bda65f?cid=2afe87a64b0042dabf51f37318616965",2.93,R.drawable.clairo);

        Song Led = new Song("add_rock_1","In The Evening","Led Zeppelin","https://p.scdn.co/mp3-preview/29c378a65973728e3acb3348a938d82f021984a9?cid=2afe87a64b0042dabf51f37318616965",6.9,R.drawable.led);
        Song Hayloft = new Song("add_rock_2","Hayloft","Mother Mother","https://p.scdn.co/mp3-preview/5b398725e0fe82979bef124872def0078d530780?cid=2afe87a64b0042dabf51f37318616965",3.03,R.drawable.mother);
        Song Stuck = new Song("add_rock_3","Let's go","Stuck in the Sound","https://p.scdn.co/mp3-preview/6e53c6236aae651c930bf284c28fce43f3dbc5e5?cid=2afe87a64b0042dabf51f37318616965",3.52,R.drawable.letsgo);
        Song Gor = new Song("add_rock_4","Rhinestone Eyes","Gorrilaz","https://p.scdn.co/mp3-preview/477094ad252a43cc492eb4bca0e4893361be212a?cid=2afe87a64b0042dabf51f37318616965",3.34,R.drawable.gorillaz);

        Song Kid = new Song("add_rap_1","Day 'N' Nite - Original Hip Hop Mix","Kid Cudi","https://p.scdn.co/mp3-preview/b4f1af50d4e206278c7915c8697859f6bcb649b6?cid=2afe87a64b0042dabf51f37318616965",3.68,R.drawable.kid);
        Song Chance = new Song("add_rap_2","Cocoa Butter Kisses","Chance The Rapper","https://p.scdn.co/mp3-preview/ffb35cd39db5ff4229af5933994d4d631252ddaf?cid=2afe87a64b0042dabf51f37318616965",5.12,R.drawable.chance);
        Song First = new Song("add_rap_3","First Class","Jack Harlow","https://p.scdn.co/mp3-preview/27913e771fb16c5439eb7e2bbc9cf62a8be09653?cid=2afe87a64b0042dabf51f37318616965",2.9,R.drawable.first);
        Song Mayo = new Song("add_rap_4","Be Gone Thot!","LIL MAYO","https://p.scdn.co/mp3-preview/bba7957fd6f6d7f9fe4ce45696655319fe7ea098?cid=2afe87a64b0042dabf51f37318616965",1.22,R.drawable.mayo);

        Song Debussy = new Song("add_class_1","Reverie, L.68","Claude Debussy","https://p.scdn.co/mp3-preview/9c43676191f0b1a60b2dee466c5da92f8f28e2e6?cid=2afe87a64b0042dabf51f37318616965",4.4,R.drawable.reverie);
        Song Franz = new Song("add_class_2","Liebestraum no 3","Franz Liszt","https://p.scdn.co/mp3-preview/4887169ffdb2bd0cac7af854024aed3f1a18d8a6?cid=2afe87a64b0042dabf51f37318616965",4.56,R.drawable.franz);
        Song Erik = new Song("add_class_3","Gymnopedie no 1","Erik Satie","https://p.scdn.co/mp3-preview/b109f2c5ccc94b96d3c468d221581c9a0ffd789e?cid=2afe87a64b0042dabf51f37318616965",3.36,R.drawable.erik);
        Song Yiruma = new Song("add_class_4","Far away","Yiruma","https://p.scdn.co/mp3-preview/1c2a6891a75a2bc0287649c2154fb5a5cf93dac0?cid=2afe87a64b0042dabf51f37318616965",3.36,R.drawable.yiruma);

        Song Falling = new Song("add_pop_1","Falling","Harry Styles","https://p.scdn.co/mp3-preview/990a7b9b1b2d3cf238964adc896e8d6943df075b?cid=2afe87a64b0042dabf51f37318616965",4,R.drawable.falling);
        Song Better = new Song("add_pop_2","Better","Khalid","https://p.scdn.co/mp3-preview/4d6e815e894da52e800d4d2d6e530b4c37471380?cid=2afe87a64b0042dabf51f37318616965",3.82,R.drawable.better);
        Song John = new Song("add_pop_3","New Light","John Mayer","https://p.scdn.co/mp3-preview/23e220f0700cc95e8ac32d7073ec877560213fe3?cid=2afe87a64b0042dabf51f37318616965",3.6,R.drawable.newlight);
        Song Hello = new Song("add_pop_4","Hello","Adele","https://p.scdn.co/mp3-preview/c9e07a3179cae95f703580aa53325ec73781ddff?cid=2afe87a64b0042dabf51f37318616965",4.93,R.drawable.hello);

        songs[0] = ImFine;
        songs[1] = JuneGloom;
        songs[2] = Moow;
        songs[3] = Wys;
        songs[4] = Always;
        songs[5] = Hybs;
        songs[6] = Soap;
        songs[7] = Clairo;
        songs[8] = Led;
        songs[9] = Hayloft;
        songs[10] = Stuck;
        songs[11] = Gor;
        songs[12] = Kid;
        songs[13] = Chance;
        songs[14] = First;
        songs[15]= Mayo;
        songs[16] = Debussy;
        songs[17] = Franz;
        songs[18] = Erik;
        songs[19] = Yiruma;
        songs[20] = Falling;
        songs[21] = Better;
        songs[22] = John;
        songs[23] = Hello;

    }
    public static int searchSongById(String id){

        for(int index=0; index < songs.length; index++){
            Song tempSong = songs[index];
            if(tempSong.getId().equals(id)){
                return index;
            }
        }
        return -1;
    }

    public Song getCurrentSong(int currentSongId){
        return songs[currentSongId];
    }
    public int getNextSong(int currentSongIndex){
        if (currentSongIndex >= songs.length-1){
            return 0;
        }
        else{
            return currentSongIndex +1;
        }
    }

    public int getPrevSong(int currentSongIndex){
        if (currentSongIndex <= 0){
            return currentSongIndex;
        }
        else{
            return currentSongIndex-1;
        }
    }

}
