package musicstream2.tp.edu.melophile2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    private ImageButton imglogo;
    private ImageButton imgwelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imglogo = (ImageButton) findViewById(R.id.logo);
        imgwelcome = (ImageButton) findViewById(R.id.welcome);
        //on click for logo and welcome to lead to login page
        imgwelcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginpage();
            }
        });
        imglogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginpage();
            }
        });
    }

    public void openloginpage() {
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

}