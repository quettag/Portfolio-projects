package musicstream2.tp.edu.melophile2.ui.home;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import musicstream2.tp.edu.melophile2.Classical_page;
import musicstream2.tp.edu.melophile2.Indie_page;
import musicstream2.tp.edu.melophile2.Lofi_page;
import musicstream2.tp.edu.melophile2.Pop_page;
import musicstream2.tp.edu.melophile2.R;
import musicstream2.tp.edu.melophile2.Rap_page;
import musicstream2.tp.edu.melophile2.Rock_page;
import musicstream2.tp.edu.melophile2.SettingsPage;
import musicstream2.tp.edu.melophile2.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {
    Activity context;

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        context = getActivity();

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        return root;
    }
    /*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(HomeFragment.this.getActivity(), Settings.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
        */


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void onStart() {
        super.onStart();
        ImageButton imgbutton1 = (ImageButton) context.findViewById(R.id.s1001);
        ImageButton imgbutton2 = (ImageButton) context.findViewById(R.id.s1002);
        ImageButton imgbutton3 = (ImageButton) context.findViewById(R.id.s1003);
        ImageButton imgbutton4 = (ImageButton) context.findViewById(R.id.s1004);
        ImageButton imgbutton5 = (ImageButton) context.findViewById(R.id.s1005);
        ImageButton imgbutton6 = (ImageButton) context.findViewById(R.id.s1006);


        Button button1 = (Button) context.findViewById(R.id.button1);
        Button button2 = (Button) context.findViewById(R.id.button2);
        Button button3 = (Button) context.findViewById(R.id.button3);
        Button button4 = (Button) context.findViewById(R.id.button4);
        Button button5 = (Button) context.findViewById(R.id.button5);
        Button button6 = (Button) context.findViewById(R.id.button6);
        imgbutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Lofi_page.class);
                startActivity(intent);
            }

        });
        imgbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Indie_page.class);
                startActivity(intent);
            }

        });
        imgbutton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Rock_page.class);
                startActivity(intent);
            }

        });
        imgbutton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Rap_page.class);
                startActivity(intent);
            }

        });
        imgbutton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Classical_page.class);
                startActivity(intent);
            }

        });
        imgbutton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Pop_page.class);
                startActivity(intent);
            }

        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Lofi_page.class);
                startActivity(intent);
            }

        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Indie_page.class);
                startActivity(intent);
            }

        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Rock_page.class);
                startActivity(intent);
            }

        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Rap_page.class);
                startActivity(intent);
            }

        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Classical_page.class);
                startActivity(intent);
            }

        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Pop_page.class);
                startActivity(intent);
            }

        });
    }

}