package musicstream2.tp.edu.melophile2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class Login extends AppCompatActivity {
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    ImageView google;
    //iniatializing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        google = findViewById(R.id.google);
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this,gso);
        TextView username = findViewById(R.id.username);
        TextView password = findViewById(R.id.password);
        Button login = (Button) findViewById(R.id.login);
        //to check if password and username is correct
        //if not correct it will prompt a message
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(v.getContext(), NavigationActivity.class);
                    startActivity(intent);

                } else

                    Toast.makeText(Login.this, "Login failed", Toast.LENGTH_SHORT).show();
            }
            //onclick for google button for sign in
        });
        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }
    void signIn(){
        Intent signInIntent = gsc.getSignInIntent();
        startActivityForResult(signInIntent,1000);
    }
    //if the request code is the same and it meets the requirements, it will lead to navigation activity to see home fragment
    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1000){
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);


            try {
                task.getResult(ApiException.class);
                opengenrepage();
            } catch (ApiException e) {
                Toast.makeText(getApplicationContext(),"something funny occured",Toast.LENGTH_SHORT).show();
            }
        }
    }
    void opengenrepage(){
        finish();
        Intent intent = new Intent(Login.this,NavigationActivity.class);
        startActivity(intent);
    }
}