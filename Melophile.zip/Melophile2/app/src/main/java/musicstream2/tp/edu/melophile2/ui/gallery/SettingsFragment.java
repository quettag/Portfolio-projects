package musicstream2.tp.edu.melophile2.ui.gallery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import musicstream2.tp.edu.melophile2.R;
import musicstream2.tp.edu.melophile2.SettingsPage;
import musicstream2.tp.edu.melophile2.databinding.FragmentSettingsBinding;



public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;
    Activity context;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SettingsViewModel homeViewModel =
                new ViewModelProvider(this).get(SettingsViewModel.class);
        context = getActivity();

        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        return root;
    }
    public void onStart(){
        super.onStart();
        Button btn = (Button) context.findViewById(R.id.signout);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, SettingsPage.class);
                startActivity(intent);

            }
        });
    }
}

