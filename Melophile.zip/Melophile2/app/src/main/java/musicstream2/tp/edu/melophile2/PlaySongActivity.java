package musicstream2.tp.edu.melophile2;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;


import java.io.IOException;

public class PlaySongActivity extends AppCompatActivity {
    AudioManager audioManager;
    //Week 7.2 Slide 13
    private String title = "";
    private String artist = "";
    private String fileLink = "";
    private int drawable;
    private int currentIndex = -1;

    private MediaPlayer player = new MediaPlayer();
    private ImageButton btnPlayPause = null;
    private SongCollection songCollection = new SongCollection();

    SeekBar seekBar;
    Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        seekBar = findViewById(R.id.seekBar2);
        //seekbar to display and drag between the duration
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player.isPlaying() && player != null) {
                    player.seekTo(seekBar.getProgress());
                }
            }
        });
        Bundle songData = this.getIntent().getExtras();
        currentIndex = songData.getInt("index");
        Log.d("temasek", "REtrieved position is :" + currentIndex);
        displaySongBasedOnIndex(currentIndex);
        playSong(fileLink);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        SeekBar seekBar = findViewById(R.id.volumeSeekBar);
        seekBar.setMax(maxVolume);
        seekBar.setProgress(currentVolume);
        //seekbar for volume
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,progress,0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
    Runnable p_bar = new Runnable() {
        @Override
        public void run() {
            if (player.isPlaying() && player != null) {
                seekBar.setProgress(player.getCurrentPosition());
            }
            handler.postDelayed(this,1000);
        }
    };

    public void displaySongBasedOnIndex(int selectedIndex) {
        Song song = songCollection.getCurrentSong(currentIndex);
        title = song.getTitle();
        artist = song.getArtist();
        fileLink = song.getFileLink();
        drawable = song.getDrawable();
        TextView txtTitle = findViewById(R.id.txtSongTitle);
        txtTitle.setText(title);
        TextView txtArtiste = findViewById(R.id.txtArtist);
        txtArtiste.setText(artist);
        ImageView iCoverArt = findViewById(R.id.imgCoverArt);
        iCoverArt.setImageResource(drawable);
    }
    public void playSong(String songUrl) {
        try {
            player.reset();
            player.setDataSource(songUrl);
            player.prepare();
            player.start();
            seekBar.setMax(player.getDuration());
            handler.removeCallbacks(p_bar);
            handler.postDelayed(p_bar,1000);

            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
            setTitle(title);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void playNext(View view) {
        currentIndex = songCollection.getNextSong(currentIndex);
        //Toast.makeText(this, "After clicking playNext,\nthe current index of this song\nin the SongCollection array is now :" + currentIndex, Toast.LENGTH_LONG).show();
        Log.d("temasek", "After playNext, the index is now :" + currentIndex);
        displaySongBasedOnIndex(currentIndex);
        playSong(fileLink);
    }
    public void playPrevious(View view) {
        currentIndex = songCollection.getPrevSong(currentIndex);
        //Toast.makeText(this, "After clicking playPrevious,\nthe current index of this song\nin the SongCollection array is now :" + currentIndex, Toast.LENGTH_LONG).show();
        Log.d("temasek", "After playPrevious, the index is now :" + currentIndex);
        displaySongBasedOnIndex(currentIndex);
        playSong(fileLink);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (player != null){
            handler.removeCallbacks(p_bar);
            player.stop();
            player.release();
            player = null;
        }
    }


    public void playOrPauseMusic(View view) {
        if (player.isPlaying()) { //if player is not playing
            player.pause();
            //changes the icon to play
            btnPlayPause.setImageResource(android.R.drawable.ic_media_play);

        } else {

            player.start();
            //changes icon to pause
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
        }
    }
}